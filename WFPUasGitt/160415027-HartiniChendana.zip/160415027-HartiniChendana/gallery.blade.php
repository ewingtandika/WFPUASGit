<html>
<head>Gallery Page</head>
<body>
	<br><br>
	<img src="{{URL::asset('/image/gambar1.jpg')}}" width='300px' height='300px'>
	<img src="{{URL::asset('/image/gambar2.jpg')}}" width='300px' height='300px'>

</body>
</html>