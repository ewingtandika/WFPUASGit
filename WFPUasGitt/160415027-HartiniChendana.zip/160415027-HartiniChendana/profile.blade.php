<html>
<head>Profile Page</head>
<body>
	<br><br>
	1.	Biography
<br>
	Full Name : Hartini Chendana	<br>
	Date of Birth & Place : Palu, 20 April 1998 <br>
	How Many Brother/Sister : 2 <br>
	Status : Single <br>
<br><br>
	2. Activity
<br>
	Works : Student College<br>
	Course : Informatics Engineering<br>
</body>
</html>